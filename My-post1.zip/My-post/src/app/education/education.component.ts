
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css'],
})
export class EducationComponent implements OnInit {


  constructor() { }
  blogs = [];

  // tslint:disable-next-line:typedef
  ngOnInit() {
  }

  // tslint:disable-next-line:typedef
  AddBlog(title, content) {
    const blog = { title: title.value, content: content.value };
    if (localStorage.getItem('blogs')) {
      this.blogs = JSON.parse(localStorage.getItem('blogs'));

    }
    this.blogs.push(blog);
    localStorage.setItem('blogs', JSON.stringify(this.blogs));
    title.value = '';
    content.value = '';
    alert('Added Blog');
  }

  // tslint:disable-next-line:typedef
  removeBlog(blog) {
    const index = this.blogs.indexOf(blog);
    this.blogs.splice(index, 1);
    localStorage.setItem('blogs', JSON.stringify(this.blogs));
    alert('Blog has been deleted..!!');
  }

}

