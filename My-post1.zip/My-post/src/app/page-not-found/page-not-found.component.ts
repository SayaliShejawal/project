import { Component, OnInit } from '@angular/core';
import { faArtstation } from '@fortawesome/free-brands-svg-icons';
import { faHome } from '@fortawesome/free-solid-svg-icons';


@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {

  public faArtstation = faArtstation;
  public faHome = faHome;

  constructor() { }

  ngOnInit(): void {
  }

}
