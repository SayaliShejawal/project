import { Component, OnInit } from '@angular/core';
import { faAt } from '@fortawesome/free-solid-svg-icons';
import { faArtstation } from '@fortawesome/free-brands-svg-icons';
import { faUnlock } from '@fortawesome/free-solid-svg-icons';


import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  public faArtstation = faArtstation;
  public faAt = faAt;
  public faUnlock = faUnlock
  public uiInvalidCredential = false;

  constructor(private fb: FormBuilder,
    private router: Router,
    private http: HttpClient) { }

  alert: boolean = false;

  ngOnInit(): void { }

  fbFormGroup = this.fb.group({
    username: ['', Validators.required],
    password: [''],
  });

  async changePass() {
    const data = this.fbFormGroup.value;

    //ajax call
    let url = 'http://localhost:3000/changepass';
    await this.http.post(url, data).toPromise();
    this.fbFormGroup.reset({});
    this.alert = true;
  }
  closeAlert() {
    this.alert = false;
  }
}
