import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog3',
  templateUrl: './blog3.component.html',
  styleUrls: ['./blog3.component.css']
})
export class Blog3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
