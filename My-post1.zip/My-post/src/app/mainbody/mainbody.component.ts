
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-mainbody',
  templateUrl: './mainbody.component.html',
  styleUrls: ['./mainbody.component.css']
})
export class MainbodyComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  // tslint:disable-next-line:typedef
  read() {
    this.router.navigate(['blog1']);
  }

  // tslint:disable-next-line:typedef
  read1() {
    this.router.navigate(['blog2']);
  }

  // tslint:disable-next-line:typedef
  read2() {
    this.router.navigate(['blog3']);
  }

  // tslint:disable-next-line:typedef
  read3() {
    this.router.navigate(['blog4']);
  }


}